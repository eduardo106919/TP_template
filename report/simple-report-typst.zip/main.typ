// main.typ

#import "lib.typ": conf

#show: conf.with(
  titulo: "Título do Trabalho Prático",
  uc: "Unidade Curricular",
  grupo: "XX",
  ano: "2025/2026",
  alunos: (
    (id: "AXXXXXX", nome: "Aluno 1"),
    (id: "AXXXXXX", nome: "Aluno 2"),
    (id: "AXXXXXX", nome: "Aluno 3"),
    (id: "AXXXXXX", nome: "Aluno 4"),
  ),
)

= Introdução
Este é um exemplo de uma nota de rodapé #footnote[Nota de exemplo para a UMinho.].

= Demonstração de Componentes

== Imagens e Figuras
Podes inserir imagens facilmente. O Typst trata da numeração.

#figure(
  image("imgs/UM.jpg", width: 60%),
  caption: [Arquitetura do Sistema proposta.],
) <fig-arq>

Como vemos na @fig-arq, a estrutura é modular.

== Tabelas
As tabelas são muito mais intuitivas que no LaTeX.

#figure(
  table(
    columns: (auto, 1fr, 1fr),
    inset: 10pt,
    align: horizon,
    [*ID*], [*Componente*], [*Estado*],
    [01], [Parser], [Concluído],
    [02], [Lexer], [Em testes],
  ),
  caption: [Estado de desenvolvimento dos módulos.],
)

#figure(
  table(
    columns: (auto, 1fr, auto),
    inset: 8pt,
    stroke: (y: 0.5pt + gray), // Linhas horizontais apenas
    table.header(
      [*Ref.*], [*Descrição do Requisito*], [*Prioridade*],
    ),
    [RF01], [O sistema deve permitir login via autenticação UMinho.], [Alta],
    [RF02], [Exportação de relatórios em formato PDF/A.], [Média],
    [RNF01], [O tempo de resposta não deve exceder 200ms.], [Crítico],
  ),
  caption: [Especificação de requisitos funcionais e não funcionais.],
)

#figure(
  table(
    columns: (1fr, 1fr, 1fr),
    inset: 10pt,
    align: center,
    stroke: 0.5pt + rgb("#dddddd"),
    [*Métrica*], [*Valor Obtido*], [*Resultado*],
    [Taxa de Erro], [0.02%], text(fill: green, weight: "bold")[Pass],
    [Uptime], [99.9%], text(fill: green, weight: "bold")[Pass],
    [Latência P99], [450ms], text(fill: red, weight: "bold")[Fail],
  ),
  caption: [Resultados dos testes de stress e confiabilidade.],
)

#figure(
  table(
    columns: (1fr, auto, auto, auto),
    inset: 10pt,
    align: horizon,
    // Cabeçalho cinza suave, linhas pares quase brancas
    fill: (x, y) => if y == 0 { rgb("#eceff1") } else if calc.even(y) { rgb("#f8f9fa") },
    stroke: 0.5pt + rgb("#d1d9e0"),
    table.header(
      [*Algoritmo*], [*Tempo (ms)*], [*Memória*], [*Precisão*],
    ),
    [A\* Search], [120], [45 MB], [100%],
    [Dijkstra], [210], [38 MB], [100%],
    [Greedy], [45], [12 MB], [85%],
  ),
  caption: [Comparação de performance com cores de leitura fácil.],
)

#figure(
  table(
    columns: (auto, 1fr, auto),
    inset: 8pt,
    stroke: none,
    // Linha dupla no topo e linha simples no fundo do cabeçalho
    table.hline(y: 0, stroke: 1.5pt + rgb("#455a64")),
    table.header(
      [*Ref.*], [*Descrição do Requisito*], [*Prioridade*],
    ),
    table.hline(y: 1, stroke: 0.8pt + rgb("#455a64")),
    [RF01], [O sistema deve permitir login via autenticação UMinho.], [Alta],
    [RF02], [Exportação de relatórios em formato PDF/A.], [Média],
    [RNF01], [O tempo de resposta não deve exceder 200ms.], [Crítico],
    table.hline(y: 4, stroke: 1pt + rgb("#455a64")),
  ),
  caption: [Especificação de requisitos com estilo formal (estilo Booktabs).],
)

#figure(
  table(
    columns: (1fr, 1fr, 1fr),
    inset: 10pt,
    align: center,
    stroke: 0.5pt + rgb("#e0e0e0"),
    fill: (x, y) => if x == 0 { rgb("#fafafa") }, // Coluna da esquerda ligeiramente cinza
    [*Métrica*], [*Valor Obtido*], [*Resultado*],
    [Taxa de Erro], [0.02%], text(fill: rgb("#2e7d32"), weight: "bold")[Pass],
    [Uptime], [99.9%], text(fill: rgb("#2e7d32"), weight: "bold")[Pass],
    [Latência P99], [450ms], text(fill: rgb("#c62828"), weight: "bold")[Fail],
  ),
  caption: [Grelha de métricas com destaque na primeira coluna.],
)

== Equações Matemáticas
Para fórmulas complexas, usamos o modo math:

$ sum_(k=0)^n k = (n(n+1)) / 2 $

Se precisares de uma variável no meio do texto, usa $x^2$.

== Código (Snippet)
Fundamental para relatórios de informática:

```python
def saudacao(nome):
    # Um comentário simples
    print(f"Olá, {nome}! Bem-vindo à EEUM.")
```

= Estado da Arte
Segundo o trabalho desenvolvido na UMinho @uminho2024, os sistemas distribuídos evoluíram significativamente. 

Como é referido no livro clássico de redes @tanenbaum2020, a camada de transporte é fundamental. 

Para a elaboração deste relatório, utilizou-se a ferramenta Typst @typst2025 pela sua eficiência na produção de documentos académicos.

= Desenvolvimento
O sistema foi implementado seguindo a arquitetura detalhada no @anexo-diagramas. 
Para verificar a listagem completa das dependências e bibliotecas utilizadas, consulte o @anexo-codigo.

As métricas brutas de desempenho, que serviram de base para a análise na sec-analise, encontram-se detalhadas no @anexo-metricas.

#pagebreak()

= Conclusão
O relatório está estruturado e pronto a exportar.

// --- Referências Bibliográficas ---
#pagebreak()

#bibliography("refs.bib", title: "Referências Bibliográficas", style: "ieee")

#pagebreak()
// --- Configuração de Anexos ---
#set heading(numbering: "A.1.")
#counter(heading).update(0)

= Anexos <anexos-root>

== Diagramas de Arquitetura <anexo-diagramas>
Nesta secção apresentam-se os diagramas UML detalhados que não couberam no corpo principal devido à sua escala.

#figure(
  rect(width: 80%, height: 100pt, stroke: 1pt + gray, [Espaço para Diagrama UML]),
  caption: [Diagrama de Classes detalhado.],
)

== Listagens de Código <anexo-codigo>
Abaixo encontra-se o ficheiro de configuração principal do projeto.

```yaml
# docker-compose.yml para ambiente de teste
services:
  db:
    image: postgres:15
    environment:
      POSTGRES_PASSWORD: uminho_ee_2024
  web:
    build: .
    ports:
      - "8000:8000"
```

== Métricas de Testes Brutas <anexo-metricas>
Os dados recolhidos durante as 48 horas de testes de carga.

#figure(
table(
columns: (auto, 1fr, 1fr),
inset: 8pt,
fill: (x, y) => if y == 0 { rgb("#eceff1") },
[*Timestamp*], [*Latência (ms)*], [*Status*],
[2024-05-10 10:00], [12], [OK],
[2024-05-10 10:05], [15], [OK],
[2024-05-10 10:10], [142], [Aviso],
),
caption: [Logs de latência do servidor de base de dados.],
)
