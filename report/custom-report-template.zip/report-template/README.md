# LaTeX Report Template

Este repositório contém um template modular em LaTeX, otimizado para relatórios técnicos da Licenciatura em Engenharia Informática da **Universidade do Minho**. O projeto está dividido em ficheiros específicos para facilitar a manutenção e a escrita colaborativa.

---

## 📂 Estrutura do Projeto

| Ficheiro / Pasta | Descrição                                                                                      |
| ---------------- | ---------------------------------------------------------------------------------------------- |
| `report.tex`     | **Ficheiro Principal.** Controla a estrutura do documento (secções, ordem dos capítulos).      |
| `preamble.tex`   | **Configurações.** Contém os pacotes, definições de cores, estilos de código e diagramas TikZ. |
| `cover.tex`      | **Capa.** Contém o design da capa institucional da UMinho.                                     |
| `refs.bib`       | **Bibliografia.** Base de dados das fontes citadas (formato BibTeX).                           |
| `imgs/`          | Pasta destinada a todas as imagens, logótipos e diagramas externos.                            |

---

## 🛠️ Como Modificar

### 1. Alterar Dados do Aluno/Grupo

Abra o ficheiro `cover.tex`. Lá poderá editar o nome da Unidade Curricular, o número do grupo e os nomes/números dos alunos na tabela `tabularx`.

### 2. Adicionar Conteúdo

Todo o texto principal deve ser escrito no `report.tex`.

- Utilize `\section{...}` para novos capítulos.
- Utilize `\subsection{...}` para divisões dentro dos capítulos.
- Para adicionar um novo anexo, desça até ao bloco `\begin{appendices}` no final do ficheiro.

### 3. Gerir Referências (`refs.bib`)

Sempre que quiser citar um livro, site ou artigo, adicione a entrada BibTeX ao ficheiro `refs.bib`. No texto do relatório, use:

```latex
Como mencionado em \cite{chave_da_fonte} ...
```

### 4. Personalizar Estilos e Cores

Se desejar alterar as cores do código, os tipos de letra ou as margens, deve editar o `preamble.tex`. As cores principais estão definidas no topo do ficheiro (ex: `UMRed`).

---

## 🖼️ Imagens e Diagramas

- **Inserir Imagem:** Coloque o ficheiro na pasta `imgs/` e use o comando:

```latex
\begin{figure}[htbp]
    \centering
    \includegraphics[width=0.5\textwidth]{nome_da_imagem.jpg}
    \caption{Descrição}
    \label{fig:label_exemplo}
\end{figure}
```

- **Diagramas TikZ:** Estão localizados na secção de diagramas do `report.tex`. Pode alterar as coordenadas e ângulos diretamente no código para ver as mudanças no PDF.

---

## 🚀 Como Compilar

Para que as referências bibliográficas e os links do índice funcionem corretamente, recomenda-se a seguinte sequência de comandos no terminal:

1. `pdflatex report.tex` (Gera o rascunho e identifica citações)
2. `biber report` (Processa a bibliografia)
3. `pdflatex report.tex` (Inclui a bibliografia no documento)
4. `pdflatex report.tex` (Finaliza a numeração e links internos)

> **Nota:** Se usar o **VS Code (com LaTeX Workshop)** ou o **Overleaf**, a compilação costuma ser automática ao guardar o ficheiro.

---

## 💡 Dicas Úteis

- **Links Clicáveis:** O índice e as citações são azuis/verdes no PDF para facilitar a navegação, mas os links do índice principal estão em preto para manter o aspeto profissional.
- **Código:** O template já inclui suporte para realce de sintaxe em várias linguagens (C, Python, Java, etc.) através do pacote `listings`.
